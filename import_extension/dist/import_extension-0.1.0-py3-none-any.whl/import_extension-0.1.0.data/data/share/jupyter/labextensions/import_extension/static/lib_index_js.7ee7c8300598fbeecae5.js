"use strict";
(self["webpackChunkimport_extension"] = self["webpackChunkimport_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__);





/**
 * Initialization data for the main menu example.
 */
const plugin = {
    id: 'import_extension:plugin',
    description: 'Minimal JupyterLab example adding a menu.',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette, _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IDefaultFileBrowser],
    activate: (app, palette, fileBrowser) => {
        const { commands } = app;
        // Add a command
        const command = 'docker:import';
        commands.addCommand(command, {
            label: 'Open Dockerfile from Path…',
            caption: 'Open Dockerfile from path',
            execute: async (args) => {
                var _a;
                // Get Dockerfile path
                let path;
                if (args === null || args === void 0 ? void 0 : args.path) {
                    path = args.path;
                }
                else {
                    path =
                        (_a = (await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getText({
                            label: 'Path',
                            placeholder: '/path/relative/to/jlab/root',
                            title: 'Open Dockerfile Path',
                            okLabel: 'Open'
                        })).value) !== null && _a !== void 0 ? _a : undefined;
                }
                if (!path) {
                    return;
                }
                try {
                    const trailingSlash = path !== '/' && path.endsWith('/');
                    if (trailingSlash) {
                        // The normal contents service errors on paths ending in slash
                        path = path.slice(0, path.length - 1);
                    }
                    const { services } = fileBrowser.model.manager;
                    const item = await services.contents.get(path, {
                        content: false
                    });
                    if (trailingSlash && item.type !== 'directory') {
                        throw new Error(`Path ${path}/ is not a directory`);
                    }
                    await commands.execute('filebrowser:go-to-path', {
                        path,
                        dontShowBrowser: args.dontShowBrowser
                    });
                    if (item.type === 'directory') {
                        return;
                    }
                }
                catch (reason) {
                    if (reason.response && reason.response.status === 404) {
                        reason.message = `Could not find path: %1 ${path}`;
                    }
                    return (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Cannot open', reason);
                }
                // Check path for dockerfile
                if (!path.toLowerCase().endsWith('dockerfile')) {
                    return (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Not a Dockerfile', "File must have extension 'Dockerfile'");
                }
                // Read Dockerfile
                const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeRequest(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.join(app.serviceManager.serverSettings.baseUrl, 'api/contents', path), {}, app.serviceManager.serverSettings);
                const file = await response.json();
                const lines = file.content.split('\n\n');
                let content = {
                    cells: [],
                    metadata: {
                        kernelspec: {
                            display_name: 'Dockerfile',
                            language: 'text',
                            name: 'docker'
                        },
                        language_info: {
                            file_extension: '.dockerfile',
                            mimetype: 'text/x-dockerfile-config',
                            name: 'docker'
                        }
                    },
                    nbformat: 4,
                    nbformat_minor: 5
                };
                const splitLines = (line) => {
                    line = line.trim();
                    let lines = line.split('\n');
                    for (var i = 0; i < lines.length - 1; i++) {
                        lines[i] += "\n";
                    }
                    return lines;
                };
                for (var line of lines) {
                    let cellType = 'code';
                    if (line.startsWith('# ')) {
                        line = line.substring(2);
                        if (!line.startsWith("%")) {
                            cellType = 'markdown';
                        }
                    }
                    content.cells.push({
                        cell_type: cellType,
                        execution_count: null,
                        id: _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__.UUID.uuid4(),
                        metadata: {},
                        outputs: [],
                        source: splitLines(line)
                    });
                }
                // Write and open Jupyter Notebook
                path += '.ipynb';
                await app.serviceManager.contents.save(path, {
                    type: 'file',
                    format: 'text',
                    content: JSON.stringify(content)
                });
                commands.execute('docmanager:open', {
                    path: path
                });
            }
        });
        // Add the command to the command palette
        const category = 'Docker';
        palette.addItem({
            command,
            category,
            args: { origin: 'from the palette' }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.7ee7c8300598fbeecae5.js.map