"use strict";
(self["webpackChunkshell_extension"] = self["webpackChunkshell_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ButtonExtension: () => (/* binding */ ButtonExtension),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);


/**
 * The plugin registration information.
 */
const plugin = {
    activate,
    id: 'toolbar-shell-button',
    autoStart: true
};
/**
 * A notebook widget extension that adds a button to the toolbar.
 */
class ButtonExtension {
    constructor(app) {
        this.app = app;
        this.currentImage = null;
    }
    /**
     * Create a new extension that shows button in the toolbar.
     * The button can be used to create a console instance for the notebook.
     *
     * @param panel Notebook panel
     * @returns Disposable on the added button
     */
    createNew(panel) {
        const createConsole = async () => {
            var _a, _b, _c, _d;
            let kernelInfo = await ((_b = (_a = panel.sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel) === null || _b === void 0 ? void 0 : _b.requestKernelInfo());
            let kernelName = (_d = (_c = panel.sessionContext.session) === null || _c === void 0 ? void 0 : _c.kernel) === null || _d === void 0 ? void 0 : _d.name;
            this.app.commands
                .execute('terminal:create-new')
                .then((widget) => {
                // If the notebook's kernel is not the Docker kernel, don't add specific code
                if (kernelName !== 'docker') {
                    return;
                }
                // If no image Id is provided by the Docker kernel, don't add specific code
                // @ts-ignore - Due to custom Kernel info in Docker Kernel
                if (kernelInfo === undefined || kernelInfo.content.imageId === null) {
                    return;
                }
                // @ts-ignore - Due to custom Kernel info in Docker Kernel
                this.currentImage = kernelInfo.content.imageId;
                widget.content.session.connectionStatusChanged.connect(initialCommand);
            });
        };
        const initialCommand = (session, status) => {
            if (status === 'connected' && this.currentImage !== null) {
                session.send({
                    type: 'stdin',
                    content: [
                        `docker run -it -w /root ${this.currentImage}` + '\r'
                    ]
                });
            }
        };
        const button = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ToolbarButton({
            className: 'create-console-button',
            label: 'Create Console',
            onClick: createConsole,
            tooltip: 'Create console for current notebook'
        });
        // 10 is the index in the standard toolbar to correctly place the button
        panel.toolbar.insertItem(10, 'createConsole', button);
        return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_0__.DisposableDelegate(() => {
            button.dispose();
        });
    }
}
/**
 * Activate the extension.
 *
 * @param app Main application object
 */
function activate(app) {
    app.docRegistry.addWidgetExtension('Notebook', new ButtonExtension(app));
}
/**
 * Export the plugin as default.
 */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.27dbe7ceb17811ed4193.js.map